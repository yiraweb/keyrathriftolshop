		confirm("Apakah anda yakin akan memesan?");
		if(==){
			alert("Pesanan anda sedang diproses. Terimakasih sudah berbelanja.")
		}
	
		//alert("Pesanan anda sedang diproses. Terimakasih sudah berbelanja.")
// confirm("Apakah anda yakin akan memesan?")
// alert("Pesanan anda sedang diproses. Terimakasih sudah berbelanja.")